const request= require('request')

const forecast = (latitude,longitude,callback) =>{
    const url = 'https://api.darksky.net/forecast/f256c0ac3bee46147f9fbf7362a0d18c/'+latitude+','+longitude+'?units=si'

        request({url ,json:true} , (error,{ body }) => {
            if(error){
              callback('unable to connect to weather service',undefined)
            }
            else if(body.error){
              callback('unable to find location',undefined)
            }
            else{
              callback(undefined,body.currently.summary+', temperature :: '+body.currently.temperature)
                
            }
    })

}

module.exports = forecast