const request= require('request')

const forecast = (latitude,longitude,callback) =>{
    // remove API_KEY and enter your api key in url constant

    const url = 'https://api.darksky.net/forecast/API_KEY/'+latitude+','+longitude+'?units=si'

        request({url ,json:true} , (error,{ body }) => {
            if(error){
              callback('unable to connect to weather service',undefined)
            }
            else if(body.error){
              callback('unable to find location',undefined)
            }
            else{
              callback(undefined,body.currently.summary+', temperature :: '+body.currently.temperature)
                
            }
    })

}

module.exports = forecast